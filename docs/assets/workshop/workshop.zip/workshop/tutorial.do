*
* INTRODUCTION TO STATA - TUTORIAL
* By: Nadia Muhe
* Data: Canadian Community Health Survey (CCHS), 2022 (Annual Component)
* Documentation: https://odesi.ca/en/details?id=/odesi/doi__10-5683_SP3_FFQB3B.xml 
* Download link: https://borealisdata.ca/data-explorer/?siteUrl=https:%2F%2Fborealisdata.ca&dvLocale=en&fileId=1002657 
*-------------------------------------------------------------------------------


*--------------------*
* STATA      
*--------------------*

* Search and Help
search excel 
help import excel


* Stata Packages
ado dir
ssc install outreg2
ado dir
ssc uninstall outreg2



*--------------------*
* IMPORTING DATA    
*--------------------*

* Working Directory
pwd
cd "/path/to/your/folder"  // paste the path to the new working directory
dir 


* Import Excel File
import excel using "cchs.xlsx", firstrow clear


* Import Stata File
use cchs.dta, clear



*--------------------*
* EXPLORING DATA
*--------------------*

* Data Overview
describe
codebook 


* Displaying Rows & Columns
list age_group in 1
list age_group in 1/3
list health mental_health activity in 60000/60005


* Frequency Table
tab mental_health
tab mental_health, m


* Two-Way Frequency Table
tab mental_health income_quintile, m
tab mental_health income_quintile, m row col cell


* Frequency Table Using fre
ssc install fre
ado dir
fre mental_health


* Missing Data
misstable summarize


* Summary Statistics
sum life_sat
sum life_sat if province=="ON"

* Grouped Summary Statistics
bysort province: sum life_sat
bysort food_security: sum life_sat
* Alternative approach to bysort
tab food_security, sum(life_sat)


*--------------------*
* GRAPHS 
*--------------------*

* Bar Chart
graph bar (count), over(stress)
graph bar (count), over(stress) title(Stress Levels in the 2022 CCHS) ytitle(Frequency) b1title(Stress Level)


* Histogram
hist life_sat
hist life_sat, discrete frequency
hist life_sat, discrete frequency title(Life Satisfaction) xtitle(Life Satisfaction Score) color(ltblue) lcolor(white)


* Scatterplot
scatter life_sat sleep_hours
scatter life_sat sleep_hours, jitter(5)
scatter life_sat sleep_hours, jitter(5) msymbol(+) msize(small) mcolor(maroon)
scatter life_sat sleep_hours, jitter(5) msymbol(+) msize(small) ///
colorvar(sex) colordiscrete colorlist(red black) coloruseplegend ///
title(Sleep Hours and Life Satisfaction by Sex) ///
ytitle(Life Satisfaction Score) ///
xtitle(Sleep Hours) ///
plegend(order(1 "Male" 2 "Female") ring(0) position(5))



*--------------------*
* NEW VARIABLES
*--------------------*

* Example 1: Binary Variable
* Food Insecurity Indicator
fre food_security

gen food_insecure = .
replace food_insecure = 0 if food_security == 1
replace food_insecure = 1 if food_security != 1 & food_security !=.
* Check
tab food_security food_insecure, m

* Add labels
label define food_insecure_label 0 "Secure" 1 "Insecure" 
label values food_insecure food_insecure_label
fre food_insecure


* Example 2: Categorical Variable
* Smoking & Drinking Risk Categories
fre smoking
fre drinking

gen risk = ""
replace risk = "Both"    if smoking == 1 & drinking == 1
replace risk = "Smoker"  if smoking == 1 & drinking != 1 & drinking != . 
replace risk = "Drinker" if smoking != 1 & drinking == 1 & smoking != .
replace risk = "Neither" if smoking != 1 & drinking != 1 & smoking != . & drinking != .
* Check
tab smoking drinking, m
tab risk, m


* Example 3: Count Variable
* Total Chronic Conditions Reported
egen chronic_count = rowtotal(diabetes hbp cholesterol mood anxiety fatigue msk cardiovascular)
* Check
tab chronic_count, m


* Example 4: Group Summary Variable
* Mean Life Satisfaction by Province
egen mean_life_sat_province = mean(life_sat), by(province)
* Check
tab province, sum(mean_life_sat_province)


*--------------------*
* SAVING DATA
*--------------------*

* Saving Stata Dataset
save cchs_analysis, replace


* Exporting Data as Excel
export excel using "cchs_analysis.xlsx", replace firstrow(variables)



*--------------------*
* MANAGING DATA
*--------------------*

* Subsetting by Variables (Columns)
use cchs_analysis, clear
keep id sleep_hours activity fruit_veg screen_workday screen_offday
save lifestyle, replace


* Subsetting by Observations (Rows)
use cchs_analysis, clear
fre age_group screen_workday screen_offday
keep if age_group == 2 & screen_workday != . & screen_offday != .
save young_adult_screen_complete, replace


* Sorting Data
use cchs_analysis, clear
sort income
gsort -income   // highest to lowest











